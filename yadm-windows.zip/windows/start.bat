@echo off
title YADM - Yet Another Display Mosque Runner
cd /d %~dp0
echo 🚀 Menjalankan YADM dari folder runner...
set PORT=3000
set HOST=0.0.0.0
node build
pause
